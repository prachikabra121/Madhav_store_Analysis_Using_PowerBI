# Madhav_Store_Analysis_PowerBI
Complete Power BI project using restail sales data 

like this video :)
